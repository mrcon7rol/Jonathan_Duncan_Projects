vti_encoding:SR|utf8-nl
vti_author:SR|SCHOOL\\jduncan963
vti_modifiedby:SR|Johnny-PC\\Johnny
vti_timelastmodified:TR|15 Dec 2013 13:22:58 -0000
vti_timecreated:TR|22 Nov 2013 14:22:21 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|decor.htm faqs.htm staff_recommendations.htm index.htm building.htm garden.htm calendar.htm staff_and_rotas.htm contact_us.htm products_currently_on_offer.htm store_location.htm home.htm showroom.htm template.htm social_networks.htm
vti_nexttolasttimemodified:TW|26 Nov 2013 12:15:08 -0000
vti_cacheddtm:TX|26 Nov 2013 12:15:10 -0000
vti_filesize:IR|957
