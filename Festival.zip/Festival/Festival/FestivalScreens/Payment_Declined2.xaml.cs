﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BSF_PrototypeScreens
{
	/// <summary>
	/// Interaction logic for Payment_Declined2.xaml
	/// </summary>
	public partial class Payment_Declined2 : UserControl
	{
		public Payment_Declined2()
		{
			this.InitializeComponent();
		}
	}
}