﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BSF_PrototypeScreens
{
	/// <summary>
	/// Interaction logic for Management_Interface2.xaml
	/// </summary>
	public partial class Management_Interface2 : UserControl
	{
		public Management_Interface2()
		{
			this.InitializeComponent();
		}
	}
}