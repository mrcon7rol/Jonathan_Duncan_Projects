import java.util.ArrayList;
import java.util.Scanner;

public class Library {
	
	//librarySectionCode = The code for the area in which the books are contained at the Library
	private int librarySectionCode;
	private String genre;
    private ArrayList<Book> myBooks = new ArrayList<Book>();
	
	
	//Constructor
	public Library(int newLibrarySectionCode, String newGenre, ArrayList newMyBooks){
		librarySectionCode = newLibrarySectionCode;
		genre = newGenre;
		myBooks = newMyBooks;
		}
	
	//Scanner
	Scanner sc = new Scanner(System.in);
	
	//Accessors
	public int getLibrarySectionCode() {
		return librarySectionCode;
	}

	public String getGenre() {
		return genre;
	}
	
	public ArrayList<Book> getMyBooks() {
		return myBooks;
	}
	
	
	//Mutators
	public void setLibrarySectionCode(int newLibrarySectionCode) {
		librarySectionCode = newLibrarySectionCode;
	}

	public void setGenre(String newGenre) {
		genre = newGenre;
	}
	
	public void setMyBooks(ArrayList<Book> newMyBooks) {
		myBooks = newMyBooks;
	}
	
	
	
	//METHODS:
	
	//Add a book
	public void addBook(){
		boolean validInput = false;
		int newBookID =0;
		String newTitle = "";
        String newAuthor = "";
        int newQuantity=0;
        
		
        //Adding a book ID
		do{	
    		System.out.println("Please enter the ID of the book you would like to add between 1 and 999: ");
    		while (!sc.hasNextInt() ){
    		    
    	    	System.err.println("Please enter valid ID between 1 and 999");
                sc.next(); 
    	        }
    		newBookID = sc.nextInt();
    		
    		for (int i = 0; i < myBooks.size(); i++) {
                if(myBooks.get(i).getBookID()!= newBookID){
                    validInput = true;
                } else { 
                    do{
                    	System.err.println("This book ID already exists, you must enter a new book ID: ");
                		while (!sc.hasNextInt() ){
                		    
                	    	System.err.println("Please enter valid ID between 1 and 999");
                            sc.next(); 
                	        }
                		newBookID = sc.nextInt();
                    	}
                    while(newBookID == myBooks.get(i).getBookID());
                    }
                }
    		   
    	  }while(newBookID <= 0 || newBookID > 999);
		
		 //Adding a title
		 do{
			 System.out.println("Please enter the title of book");
			 newTitle = sc.next();
			 if(!(newTitle.matches("[a-zA-Z]+$"))){
				 System.err.println("You must enter the title using letters from the alphabet");
				 newTitle = sc.next();
			 
			 for (int i = 0; i < myBooks.size(); i++){
				 if (myBooks.get(i).getTitle().equalsIgnoreCase(newTitle)){
					 System.err.println("This book already exists, you must enter a new title");
					 sc.next();
					 } else { validInput = true;
					 }
				 }
			 }
		 }
		 while (!validInput);
		
		 
		 //Adding an author
		 do{System.out.println("Enter the author of the book:");
			newAuthor= sc.next();
		 if (!(newAuthor.matches("[a-zA-Z]+$"))){
			 System.err.println("You must enter the authors name using letters from the alphabet");
			 newAuthor = sc.next();
			 
		 } else {
			 validInput = true;
		 }
	}
		 while(!validInput); 	
		 
		//Adding a quantity
		 do {
				System.out.println("Please enter a quantity between 1 and 99 ");
				while (!sc.hasNextInt()){
 	    		  System.err.println("You must enter valid quantity ");
 		          sc.next();}
	            newQuantity = sc.nextInt();
	            
	            if(newQuantity > 0 && newQuantity <100){   		            	
	            	validInput = true;
	            } 
	            
	            else{
	            	validInput = false;
	            	System.err.println("This quantity is not valid");
	            	System.out.println("");
	            	}
	            } 
		 while (!validInput);
	
	//Adds the book to the array list	 
	Book newBook = new Book(newBookID, newTitle, newAuthor, false, newQuantity, 0);
	myBooks.add(newBook);
	
	//Prints out the details of every book including the new book
	System.out.println("List of Books and their details (Including the new book!):");
	System.out.println("--------------------------------------------------------------");
	
	for(int i = 0; i <myBooks.size(); i++){ 
		System.out.println("--------------------------------------------------------------");
		System.out.println("Book ID: " + myBooks.get(i).getBookID()); 
		System.out.println("Title: " + myBooks.get(i).getTitle()); 
		System.out.println("Author: " + myBooks.get(i).getAuthor());
		System.out.println("On Loan: " + myBooks.get(i).getOnLoan());
		System.out.println("Quantity: " + myBooks.get(i).getQuantity());
		System.out.println("Number Of Loans: " + myBooks.get(i).getNumOfLoans());
		System.out.println("--------------------------------------------------------------");
		}
	}
	
	//Edit a book's details
	public void editBook(){
		
		String  newAuthor, newTitle;
		int newQuantity, choice, editBookID, newBookID;
		boolean validInput = false;
		
	//Editing the book ID
	do{	
		System.out.println("Please enter the ID of the book you would like to edit: ");
		while (!sc.hasNextInt() ){
		    
	    	System.err.println(" Please enter valid ID ");
            sc.next(); 
	        }
		editBookID = sc.nextInt();
		   
	  }while(editBookID <= 0 || editBookID > 999);
    
	
    for(int i = 0; i < myBooks.size(); i++)
    	{
    	if(editBookID==myBooks.get(i).getBookID()){
    		//Once user enters in the number of the book the details of it are displayed
    		System.out.println("The details of this book are:");
    		System.out.println("Book ID: " + myBooks.get(i).getBookID()); 
    		System.out.println("Title: " + myBooks.get(i).getTitle()); 
    		System.out.println("Author: " + myBooks.get(i).getAuthor());
    		System.out.println("Quantity: " + myBooks.get(i).getQuantity());
    		System.out.println("--------------------------------------------------------------");
    		 
    		//Once the details are displayed the user is then given the option of what they would like to edit
    		//Validation ensures they can only pick a number from 1-4
    		 do{
    		 System.out.println("What would you like to edit?");
    	     System.out.println("--------------------------------------------------------------");
    	     System.out.println("1: Book ID");
    	     System.out.println("2: Title");
    	     System.out.println("3: Author");
    	     System.out.println("4: Quantity");
    	     System.out.println("5: Return to main menu");
    	     System.out.println("--------------------------------------------------------------");
    	     choice = sc.nextInt();
    	     
    	      
    	      switch(choice){
    	      
    	     //If 1 is typed in the user can edit the Book ID
 			 //The validation allows the user to only enter in integers for the new Book ID
    	      case(1):{ 
    	    	  do{
    	    	  System.out.println("Enter a new Book ID between 1 and 999:");
    	    	  while (!sc.hasNextInt()){
    	    		  System.err.println("You must enter a valid Book ID ");
			          sc.next();
			          }
    	    	  
    	    	  newBookID = sc.nextInt();
                  
               	for (int j = 0; j < myBooks.size(); j++) {
      				
     				 
      				if(newBookID==(myBooks.get(j).getBookID())){	 
      				
      						do{System.err.println("This Book ID already exists, you must enter in a new Book ID");
      					 
      					     newBookID =sc.nextInt();
      					     }
      						while(newBookID ==(myBooks.get(j).getBookID()));
      						}
      				}
               	} 
    	      while (newBookID <= 0 || newBookID > 999);
                  
					myBooks.get(i).setBookID(newBookID);
                  System.out.println("The Book ID has been changed");
				}
				break;
    	     
			 //If 2 is typed in the user can edit the title
			 //The validation allows the user to only enter in letters from the alphabet for the new title
    	     case(2):
    	    	 
    	    	 do{
    			 System.out.println("Please enter the new title of book");
    			 newTitle = sc.next();
    			 if(!(newTitle.matches("[a-zA-Z]+$"))){
    				 System.err.println("You must enter the title using letters from the alphabet");
    				 newTitle = sc.next();
    			 
    			 for (int j = 0; j < myBooks.size(); j++){
    				 if (myBooks.get(i).getTitle().equalsIgnoreCase(newTitle)){
    					 System.err.println("This book already exists, you must enter a new title");
    					 sc.next();
    					 } else { validInput = true;
    					 }
    				 }
    			 }
    		 }
    		 while (!validInput);
    	     myBooks.get(i).setTitle(newTitle);
             System.out.println("Title has been changed!");
    	     break;
                  
    	     //If 3 is typed in the user can edit the author
    	     /*It is taken into account that an author can have multiple books so the author validation 
    	     is different to the title validation*/
    		 case(3): do{System.out.println("Enter the author of the book:");
 						newAuthor= sc.next();
 						
 			 if (!(newAuthor.matches("[a-zA-Z]+$"))){
 				 System.err.println("You must enter the authors name using letters from the alphabet");
 				 newAuthor = sc.next();
 				 
 			 } else {
 				 validInput = true;
 			 }
 		}
 			 while(!validInput);
    		 myBooks.get(i).setAuthor(newAuthor);
             System.out.println("Author has been changed!");
             break;
                 
    	     //If 4 is typed in the user can edit the quantity
             //Validation ensures that the user can only enter in a number between 1 and 99
    		 case(4): 
    			 do {
    					System.out.println("Please enter a quantity between 1 and 99 ");
    					while (!sc.hasNextInt()){
  		  	    		  System.err.println("You must enter valid quantity ");
  		  		          sc.next();}
    		            newQuantity = sc.nextInt();
    		            
    		            if(newQuantity > 0 && newQuantity <100){   		            	
    		            	validInput = true;
    		            } 
    		            
    		            else{
    		            	validInput = false;
    		            	System.err.println("This quantity is not valid");
    		            	}
    		            } 
    			 while (!validInput); 
    		 	 myBooks.get(i).setQuantity(newQuantity);
    		     System.out.println("The quantity has been changed");
    	      	break; 
    	      	
    	     //Return to the menu
    		 case(5): break;
    		 
    		 default: System.err.println("That number is invalid! \nYou must enter a value between 1 and 4\n");
    	      	}}
    		 while(choice!=5);
               
    	      
    	      
    	      //Displays the details of the edited book
    	      System.out.println("--------------------------------------------------------------");
    	      System.out.println("The details of the edited book are:");
    	      System.out.println("Book ID: " + myBooks.get(i).getBookID()); 		    
    	      System.out.println("Title: " + myBooks.get(i).getTitle()); 		    	
    	      System.out.println("Author: " + myBooks.get(i).getAuthor());	    	
    	      System.out.println("Quantity: " + myBooks.get(i).getQuantity());
    	      System.out.println("--------------------------------------------------------------");
    		 }
    	}
    }
	
	//Delete Book
	public void deleteBook(){
		int bookID = 0;
		boolean validInput = false;
		boolean choice;
	
	//Asks the user to enter a Book ID to delete
	do{
  	  System.out.println("Enter a Book ID between 1 and 999: ");
  	  while (!sc.hasNextInt()){
  		  System.err.println("You must enter a valid Book ID ");
	          sc.next();
	          }
  	  bookID = sc.nextInt();
  	  
  	if(bookID > 0 && bookID <1000){   		            	
    	validInput = true;
    } 
    
    else{
    	validInput = false;
    	System.err.println("This quantity is not valid");
    	}
	
  	//Displays details of the Book from the book ID entered in
	for(int i = 0; i <myBooks.size(); i++){ 
	     
		if(bookID==myBooks.get(i).getBookID()){
	    		System.out.println("Book ID: " + myBooks.get(i).getBookID()); 
	    		System.out.println("Title: " + myBooks.get(i).getTitle()); 
	    		System.out.println("Author: " + myBooks.get(i).getAuthor());
	    		System.out.println("Quantity: " + myBooks.get(i).getQuantity());
	    		System.out.println("");
	    		
	    		//Ask the user if they are sure they want to delete the book
	    	    System.out.println("Are you sure you want to delete this book? (Please answer in true or false)");
	    	    	  while (!sc.hasNextBoolean()){
	    	    		  System.err.println("You must enter a choice as true or false! ");
	    	  	          sc.next();
	    	  	          }
	    	    	  choice = sc.nextBoolean();
	    	    	  
	    	    //Book is deleted if user enters true
	    	    if (choice == true){
	    	    	myBooks.remove(i);
	    	    	System.out.println("The book has been deleted" );
	    	    	System.out.println("--------------------------------------------------------------");
	    	    	System.out.println("The new list of books is: ");
	    	    	System.out.println("--------------------------------------------------------------");
	    	    	
	    	    	//Displays all the books in the system after the book has been deleted
	    	    	for(int j = 0; j <myBooks.size(); j++){
	    	    		System.out.println("Book ID: " + myBooks.get(j).getBookID());
	    	    		System.out.println("Title: " + myBooks.get(j).getTitle());
	    	    		System.out.println("Author: " + myBooks.get(j).getAuthor());
	    	    		System.out.println("On Loan: " + myBooks.get(j).getOnLoan());
	    	    		System.out.println("Quantity: " + myBooks.get(j).getQuantity());
	    	    		System.out.println("Number of Loans: " + myBooks.get(j).getNumOfLoans());
	    	    		System.out.println("--------------------------------------------------------------");
	    	    		}
	    	    }
	    	    //Book is not deleted if user enters false
	    	    else System.out.println("The book has not been deleted");
	    	    System.out.println("-------------------------------------------------------------");
	    	    
		}}} while(!validInput);
	
}
		
	//Loan a book
	public void loanBook(){   
		int bookID=0;
		boolean validInput = false;
		int addToLoan;
		
		//Asks the user to enter a Book ID to loan
		do{
		  	  System.out.println("Enter a Book ID between 1 and 999: ");
		  	  while (!sc.hasNextInt()){
		  		  System.err.println("You must enter a valid Book ID between 1 and 999 ");
			          sc.next();
			          }
		  	  bookID = sc.nextInt();
		  	  
		  	if(bookID > 0 && bookID <1000){   		            	
		    	validInput = true;
		    } 
		    
		    else{
		    	validInput = false;
		    	System.err.println("This quantity is not valid");
		    	}
			
			
			//Loans out the book and adds one to the number of loans	
			for(int i = 0; i <myBooks.size(); i++){ 
			     
				if(bookID==myBooks.get(i).getBookID()){
					if (myBooks.get(i).getNumOfLoans() < myBooks.get(i).getQuantity()){
						addToLoan = myBooks.get(i).getNumOfLoans()+1;
						myBooks.get(i).setNumOfLoans(addToLoan);
						System.out.println(myBooks.get(i).getTitle() + " is now on loan!");
						
						//If the book is loaned out and the number of loans now equals the quantity, the onLoan is set to true!
						if (myBooks.get(i).getNumOfLoans() == myBooks.get(i).getQuantity()){
							myBooks.get(i).setOnLoan(true);
							System.out.println("This book has now been completely loaned out! This book cannot be loaned anymore!");
						}
					
					//Displays the details of the book that has just been loaned out
				    System.out.println("--------------------------------------------------------------");
			   		System.out.println("Book ID: " + myBooks.get(i).getBookID()); 
			   		System.out.println("Title: " + myBooks.get(i).getTitle()); 
			   		System.out.println("Author: " + myBooks.get(i).getAuthor());
			   		System.out.println("On Loan: " + myBooks.get(i).getOnLoan());
			    	System.out.println("Quantity: " + myBooks.get(i).getQuantity());
			    	System.out.println("Number Of Loans: " + myBooks.get(i).getNumOfLoans());
		    	    System.out.println("--------------------------------------------------------------");}
		    	    else {
						System.out.println("All copies of " + myBooks.get(i).getTitle() + " are currently on loan, do not loan it out!!");
		    	    }
					
					
		  		  }
			}}while (!validInput);
			}
	
	//Return a book
	public void returnBook(){   
		
		int bookID=0;
		boolean validInput = false;
		int removeToLoan;
		
		//Asks the user to enter a Book ID to return
		do{
		  	  System.out.println("Enter a Book ID between 1 and 999: ");
		  	  while (!sc.hasNextInt()){
		  		  System.err.println("You must enter a valid Book ID between 1 and 999");
			          sc.next();
			          }
		  	  bookID = sc.nextInt();
		  	  
		  	if(bookID > 0 && bookID <1000){   		            	
		    	validInput = true;
		    } 
		    
		    else{
		    	validInput = false;
		    	System.err.println("\nThis quantity is not valid");
		    	}
			
			
		    //Returns the book and minuses one to the number of loans		
			for(int i = 0; i <myBooks.size(); i++){ 
			     
				if(bookID==myBooks.get(i).getBookID()){
					if (myBooks.get(i).getNumOfLoans() > 0){
						removeToLoan = myBooks.get(i).getNumOfLoans()-1;
						myBooks.get(i).setNumOfLoans(removeToLoan);
						System.out.println(myBooks.get(i).getTitle() + " has now been returned!");
						
						//If the book is returned and the number of loans doesn't equal the quantity, the onLoan is set to false!
						if (myBooks.get(i).getNumOfLoans() != myBooks.get(i).getQuantity()){
							myBooks.get(i).setOnLoan(false);
							System.out.println(myBooks.get(i).getTitle()+" is available to loan!");
						}
					
					//Displays the details of the book that has just been returned
				    System.out.println("--------------------------------------------------------------");
			   		System.out.println("Book ID: " + myBooks.get(i).getBookID()); 
			   		System.out.println("Title: " + myBooks.get(i).getTitle()); 
			   		System.out.println("Author: " + myBooks.get(i).getAuthor());
			   		System.out.println("On Loan: " + myBooks.get(i).getOnLoan());
			    	System.out.println("Quantity: " + myBooks.get(i).getQuantity());
			    	System.out.println("Number Of Loans: " + myBooks.get(i).getNumOfLoans());
		    	    System.out.println("--------------------------------------------------------------");}
		    	    else {
						System.err.println(myBooks.get(i).getTitle()+" has zero loans, it cannot be returned!\n ");
		    	    }
				}
			}
		}
		while (!validInput);
}
	
	
	//Display all books
	public void displayAllBooks(){
		System.out.println("--------------------------------------------------------------");
		System.out.println("List of Books: ");
		
		    //Displays the details of all books
			for(int i = 0; i <myBooks.size(); i++){
				System.out.println("--------------------------------------------------------------");
				System.out.println("Book ID: " + myBooks.get(i).getBookID()); 
				System.out.println("Title: " + myBooks.get(i).getTitle()); 
				System.out.println("Author: " + myBooks.get(i).getAuthor());
				System.out.println("On Loan: " + myBooks.get(i).getOnLoan());
				System.out.println("Quantity: " + myBooks.get(i).getQuantity());
				System.out.println("Number Of Loans: " + myBooks.get(i).getNumOfLoans());
				System.out.println("--------------------------------------------------------------");
				}
			}

		
	//Search for a book(s) by author
	public void searchAuthor(){
			
		String searchAuthor;
		
		//Asks the user to enter the author
		System.out.println("Enter the author you want to search for:");
		searchAuthor = sc.next();
		
		while (!(searchAuthor.matches("[a-zA-Z]+$"))){
			System.err.println("You must enter the authors name using letters from the alphabet");
			searchAuthor = sc.next();
			}
		
		while(!(searchAuthor.matches("[a-zA-Z]+$")));
		System.out.println("The book(s) by this author is:");
		//Prints out the details of the book once the author has been searched for
		for (int i = 0; i < myBooks.size(); i++){
			if(searchAuthor.equals(myBooks.get(i).getAuthor())){
				System.out.println("--------------------------------------------------------------");
				System.out.println("Book ID: " + myBooks.get(i).getBookID());
				System.out.println("Title: " + myBooks.get(i).getTitle());
				System.out.println("On Loan: " + myBooks.get(i).getOnLoan());
				System.out.println("Number of loans: " + myBooks.get(i).getNumOfLoans());
				System.out.println("--------------------------------------------------------------");
				}
			}
		}

	private static int[] bookIDs = {
			1, 2, 3, 4, 5, 
			};
		
	private static String[] titles = {
			"The Hunger Games", "Divergent", "The Maze Runner", "Stormbreaker", "Harry Potter"	
			};
		
	private static String[] authors = {
			"Collins", "Roth", "Roth", "Horowitz", "Rowling"	
			};	
		
	private static boolean[] onLoan = {
			true, false, false, true, false
			};
	
	private static int[] quantity = {
			3, 5, 6, 2, 1	
			};
	
	private static int[] numOfLoans = {
			3, 2, 5, 2, 0
			};
	
	public static ArrayList<Book> generateBooks(){
		ArrayList<Book> books = new ArrayList<Book>();
		
		for(int i=0; i<bookIDs.length; i++){
			books.add(new Book(bookIDs[i], titles[i], authors[i], onLoan[i], quantity[i], numOfLoans[i]));}
		
		return books;
	}
	
}
	
	
	
	
	
			
			
