import java.util.ArrayList;
import java.util.Scanner;

public class LibraryTester {
	

	public static void main(String[] args) {
		
		//Create a scanner
		Scanner sc = new Scanner(System.in);
		
	
		//Create an ArrayList of books
		ArrayList<Book> myBooks = new ArrayList<Book>();
		myBooks = Library.generateBooks();
		
		//Create a Library
		Library action = new Library(1, "Action", myBooks);
		
		//Asks the user for their name and welcomes them to the library system
		System.out.println("Hello! \nWhat is your name?");
		String username = sc.nextLine();
		System.out.println("Welcome to the library system " + username + "!");
		
		//Prints out area code and genre of the library
		System.out.println("--------------------------------------------------------------");
		System.out.println("Area code: " + action.getLibrarySectionCode());
		System.out.println("Genre: " + action.getGenre());
		System.out.println("--------------------------------------------------------------");		
		
		int userOption;
		
		//Beginning of the do loop
		do { userOption = printMenu(sc);
		switch(userOption){
		
		//User can enter 1 to add a book
		case 1: action.addBook();
	    break;
		
	    //User can enter 2 to edit a book
		case 2: action.editBook();
		break;
		
		//User can enter 3 to delete a book
		case 3: action.deleteBook();
	    break;
	    
	    //User can enter 4 to loan a book
		case 4: action.loanBook();
		break;
		
		//User can enter 5 to return a book
		case 5: action.returnBook();
		break;
		
		//User can enter 6 to search for books by an author
		case 6: action.searchAuthor();
		break;
		
		//User can enter 7 to display to all the books and their details
		case 7: action.displayAllBooks();
		break;
		
		//User can enter 8 to terminate the program
		case 8: System.err.println("Program terminated, please restart the program if you wish to continue!");
		System.exit(0); 
		break;
		
		//Ensures the user can only enter in a number between 1 and 8
		default: System.err.println("Invalid option! \nPlease enter a number between 1 and 8!\n");
		}
	}	
		while(userOption !=8);//End of the do loop
}
		
	//Print menu method                                                                        
	public static int printMenu(Scanner sc) {
		
		System.out.println("What would you like to do today?");
		System.out.println("1: Add a Book");
		System.out.println("2: Edit a Book");
		System.out.println("3: Delete a Book");
		System.out.println("4: Loan a Book");
		System.out.println("5: Return a Book");
		System.out.println("6: Search for a book(s) by author");
		System.out.println("7: Display details of all the books currently in the system");
		System.out.println("8: Exit System");
		
		//Validation to ensure the user enters an integer
		while(!sc.hasNextInt()){
			System.err.println("You must enter a number between 1 and 8");
			sc.next();}		
		int userOption = sc.nextInt();
		return userOption;
		}
	}


