public class Book {
	
	private int bookID;
	private String title;
	private String author;
	private boolean onLoan;
	private int quantity;
	private int numOfLoans;
		
	public Book(int newBookID, String newTitle, String newAuthor, boolean newOnLoan, int newQuantity, int newNumOfLoans){
		bookID = newBookID;
		title = newTitle;
		author = newAuthor;
		onLoan = newOnLoan;
		quantity = newQuantity;
		numOfLoans = newNumOfLoans;
	}
	
	//Accessors
	public int getBookID() {
		return bookID;
		}
	public String getTitle(){
		return title;
		}
			
	public String getAuthor(){
		return author;
		}
			
	public boolean getOnLoan() {
		return onLoan;
		}
			
	public int getNumOfLoans() {
		return numOfLoans;
		}
	
	public int getQuantity() {
		return quantity;
		}
	
	//Mutators
	public void setBookID(int newBookID){
		bookID = newBookID;
		}
	
	public void setTitle(String newTitle){
		title = newTitle;
		}
			
	public void setAuthor(String newAuthor){
		author = newAuthor;
		}
			
	public void setOnLoan(boolean newOnLoan){
	    onLoan = newOnLoan;
		}
			
	public void setNumOfLoans(int newNumOfLoans){
		numOfLoans = newNumOfLoans;
		newNumOfLoans++;
		}
	
	public void setQuantity(int newQuantity){
		quantity = newQuantity;
		}
	
	
}

		
		
		

	


